// This is a test harness for your module
// You should do something interesting in this harness
// to test out the module and to provide instructions
// to users on how to use it by example.


// open a single window
var win = Ti.UI.createWindow({
    backgroundColor:'white'
});
var label = Ti.UI.createLabel();
win.add(label);
win.open();

// TODO: write your module tests here
    var helpshift = require('com.helpshift.ios');
    helpshift.installApp('<appID>', '<domainName>', '<apiKey>', {"disableInAppNotif" : "<YES/NO>"});

    var label1 = Ti.UI.createLabel({
      color: '#987',
      text: 'Show Conversation after issue report',
      textAlign: Ti.UI.TEXT_ALIGNMENT_CENTER,
      top: 10,
      width: Ti.UI.SIZE, height: 20
    });
    var ConvSwitch = Ti.UI.createSwitch({
      value:true, // mandatory property for iOS
      top: 30
    });

    var label2 = Ti.UI.createLabel({
      color: '#987',
      text: 'Show report issue button on search',
      textAlign: Ti.UI.TEXT_ALIGNMENT_CENTER,
      top: 60,
      width: Ti.UI.SIZE, height: 20
    });

    var ReportIssueSwitch = Ti.UI.createSwitch({
      value:true, // mandatory property for iOS
      top: 80
    });


     var showSupport = Titanium.UI.createButton({
     title: 'Show support',
     top: 120,
     width: 150,
     height: 50
  });
  showSupport.addEventListener('click',function(e) {
     Titanium.API.info("You clicked showSupport");
     var notifCount = helpshift.notificationCountAsync(true);
     Titanium.API.info("Notif count is " + notifCount);
     if (ConvSwitch.value)
         helpshift.showSupport({showConvOnReportIssue:"yes"});
     else
         helpshift.showSupport({showConvOnReportIssue:"no"});
  });

  var reportIssue = Titanium.UI.createButton({
     title: 'Report issue',
     top: 170,
     width: 150,
     height: 50
  });
  reportIssue.addEventListener('click',function(e) {
     Titanium.API.info("You clicked reportIssue");
     if (ConvSwitch.value)
        helpshift.reportIssue({showConvOnReportIssue:"yes"});
     else
        helpshift.reportIssue({showConvOnReportIssue:"no"});
  });

  var showFaqSection = Titanium.UI.createButton({
     title: 'Show faq section',
     top: 220,
     width: 150,
     height: 50
  });
  showFaqSection.addEventListener('click',function(e) {
     Titanium.API.info("You clicked show faq section");
     helpshift.showFaqSection(73);
  });

  var showFaq = Titanium.UI.createButton({
     title: 'Show faq question',
     top: 270,
     width: 150,
     height: 50
  });
  showFaq.addEventListener('click',function(e) {
     Titanium.API.info("You clicked show faq section");
     helpshift.showFAQ(151);
  });

  var showInbox = Titanium.UI.createButton({
     title: 'Show Inbox',
     top: 320,
     width: 150,
     height: 50
  });
  showInbox.addEventListener('click',function(e) {
     Titanium.API.info("You clicked show faq section");
     helpshift.showInbox();
  });

  var showFaqs = Titanium.UI.createButton({
     title: 'Show faqs',
     top: 370,
     width: 150,
     height: 50
  });
  showFaqs.addEventListener('click',function(e) {
     Titanium.API.info("You clicked show faq section");
    var reportIssueFlag = "no", convOnReportIssue = "no";
    if (ReportIssueSwitch.value)
           reportIssueFlag = "yes"
    if (ConvSwitch.value)
      convOnReportIssue = "yes";

    helpshift.showFAQs({showReportIssue : reportIssueFlag, showConvOnReportIssue : convOnReportIssue});

  });

    win.add(label1);

    win.add(label2);
    win.add(ConvSwitch);
    win.add(ReportIssueSwitch);

  win.add(showSupport);
  win.add(reportIssue);
  win.add(showFaqSection);
  win.add(showFaq);
  win.add(showFaqs);
  win.add(showInbox);

  helpshift.addEventListener('notificationCountAsyncReceived', function  (data) {Ti.API.info("1 : Got a callback !!" + data.count)});
  helpshift.addEventListener('helpshiftSessionHasEnded', function  (data) {Ti.API.info("2 : Got a callback !!")});

    Ti.App.iOS.addEventListener('notification', function(e){
        if (e["userInfo"]["origin"] == "helpshift")
            helpshift.handleLocalNotification(e["userInfo"]["issue_id"]);
    });
